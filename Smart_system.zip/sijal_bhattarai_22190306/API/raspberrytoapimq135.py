import paho.mqtt.client as mqtt
import time
import json

import requests

# Callback when the client connects to the MQTT broker
def on_connect(client, userdata, flags, rc):
    print(f"Connected with result code {rc}")
    client.subscribe("cmp5324/sijal/MQ135")

# Callback when a message is received from the MQTT broker

def on_message(client, userdata, msg):
    payload = msg.payload.decode()
    print(payload)

    try:
        # Assuming the received payload is a JSON string
        json_data = json.loads(payload)

        # Access and print specific values
        methane = json_data.get("Methane")
        ammonia = json_data.get("Ammonia")

        carbondioxide = json_data.get("CarbonDioxide")

    
        
        if methane is not None and ammonia is not None:
            print(f"methane: {methane}, ammonia: {ammonia}, carbondioxide: {carbondioxide}")

            # Make an HTTP POST request to your API
            api_url = "http://localhost:5257/api/Sijal/Sensor/MQ135DataPost"
            data = "{'methane':"+ str(round(methane, 2))+", 'ammonia':" +str(round(ammonia,2))+", 'carbondioxide':"+ str(round(carbondioxide,2))+"}"
            headers = {"Content-Type": "application/json"}
            response = requests.post(api_url, data=json.dumps(data), headers=headers)

            if response.status_code == 200:
                print("Data posted successfully to the API")
            else:
                print(f"Failed to post data to the API. Status code: {response.status_code}")

    except json.JSONDecodeError as e:
        print(f"Error decoding JSON: {e}")


# Set your MQTT broker address, port, username, and password
broker_address = "192.168.165.126"
broker_port = 1883
mqtt_username = "sijal"
mqtt_password = "sijal"

client = mqtt.Client()
client.on_connect = on_connect
client.on_message = on_message

# Set username and password
client.username_pw_set(mqtt_username, mqtt_password)

# Connect to the MQTT broker
client.connect(broker_address, broker_port, 60)

# Start the MQTT client loop in the background
client.loop_start()

try:
    while True:
        # Continue looping to receive messages
        time.sleep(1)

except KeyboardInterrupt:
    print('\nDisconnecting...')
    client.loop_stop()
    client.disconnect()
    exit()
